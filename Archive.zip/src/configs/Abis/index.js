import PresaleAbi from "./TumaPresale.json"

export { PresaleAbi }
