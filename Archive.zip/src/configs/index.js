export const DECIMAL_COIN = 18
