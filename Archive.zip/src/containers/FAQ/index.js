import FAQComponent from "components/FAQ"

const FAQ = () => {
  return <FAQComponent />
}

export default FAQ
