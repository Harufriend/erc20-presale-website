import PresaleComponent from "components/Presale"

const PresaleContainer = () => {
  return <PresaleComponent />
}

export default PresaleContainer
