import { ReactComponent as Metamask } from "./metamask.svg"
import { ReactComponent as WalletConnect } from "./walletconnect.svg"

export { Metamask, WalletConnect }
