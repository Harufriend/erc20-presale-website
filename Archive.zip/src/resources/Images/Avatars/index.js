import LoganJackson from "./logan_jackson.png"
import RocilFortune from "./rocil_fortune_a_malanda.png"
import RussiaNguimbi from "./russia_nguimbi.png"

export { LoganJackson, RocilFortune, RussiaNguimbi }
