import Logo from "./logo.png"
import PartnerPlaceholder from "./partner-placeholder.png"
import FounderPlaceholder from "./founder-placeholder.png"
import IntroduceVideo from "./introduce-video.png"

export { Logo, PartnerPlaceholder, FounderPlaceholder, IntroduceVideo }
