import CarouselBackground from "./carousel-bg.mp4"

export { CarouselBackground }
