import DashboardContainer from "containers/Dashboard"

const Dashboard = () => <DashboardContainer />

export default Dashboard
