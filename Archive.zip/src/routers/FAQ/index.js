import FAQContainer from "containers/FAQ"

const FAQ = () => <FAQContainer />

export default FAQ
