import PresaleContainer from "containers/Presale"

const Presale = () => <PresaleContainer />

export default Presale
